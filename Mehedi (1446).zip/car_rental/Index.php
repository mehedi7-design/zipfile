<?php include 'config.php'; ?>
<?php include 'header.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Car Rental Pro</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="hero">
    <h1>🚗 Premium Car Rental Service</h1>
    <p>Fast • Safe • Affordable Car Booking Platform</p>
    <a class="btn" href="register.php">Get Started</a>
</div>

<div class="container">
    <h2>Available Cars</h2>

    <div class="car-grid">

    <?php
    $result = mysqli_query($conn, "SELECT * FROM cars");

    while($row = mysqli_fetch_assoc($result)){
        echo "
        <div class='car'>
            <img src='images/{$row['image']}'>
            <h3>{$row['name']}</h3>
            <p class='price'>৳ {$row['price']} / day</p>
            <a class='btn' href='login.php'>Book Now</a>
        </div>";
    }
    ?>

    </div>
</div>

<?php include 'footer.php'; ?>

</body>
</html>