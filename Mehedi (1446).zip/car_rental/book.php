<?php
session_start();
include 'config.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get car id from URL
$car_id = $_GET['car_id'];

// Fetch car data
$car = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM cars WHERE id='$car_id'")
);

// Safety check
if(!$car){
    die("Car not found");
}

// Handle booking
if(isset($_POST['book'])){
    $date = $_POST['date'];

    mysqli_query($conn, "
        INSERT INTO bookings(user_id, car_id, booking_date)
        VALUES('$user_id', '$car_id', '$date')
    ");

    header("Location: success.php");
    exit();
}
?>

<?php include 'header.php'; ?>
<link rel="stylesheet" href="style.css">

<div class="hero">
    <h1>Book Your Car 🚗</h1>
    <p>Select your preferred date</p>
</div>

<div class="container">

    <!-- CAR CARD -->
    <div class="car" style="max-width:300px; margin:auto;">
        <img src="images/<?php echo $car['image']; ?>">
        <h3><?php echo $car['name']; ?></h3>
        <p class="price">৳ <?php echo $car['price']; ?> / day</p>
    </div>

    <!-- BOOKING FORM -->
    <div class="form-box">

        <h2>Select Booking Date</h2>

        <form method="POST">
            <input type="date" name="date" required>

            <button type="submit" name="book">
                Confirm Booking 🚗
            </button>
        </form>

    </div>

</div>

<?php include 'footer.php'; ?>