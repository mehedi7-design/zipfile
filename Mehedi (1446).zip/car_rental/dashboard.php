<?php
session_start();
include 'config.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
}

$user_id = $_SESSION['user_id'];

// Get user info
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id='$user_id'"));

// Stats
$totalCars = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM cars"));
$totalBookings = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM bookings WHERE user_id='$user_id'"));
?>

<?php include 'header.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<!-- HERO -->
<div class="hero">
    <h1>Welcome, <?php echo $user['name']; ?> 🚗</h1>
    <p>Your premium car rental dashboard</p>
</div>

<!-- STATS -->
<div class="container">

<div class="stats">

    <div class="stat-box">
        <h2><?php echo $totalCars; ?></h2>
        <p>Total Cars</p>
    </div>

    <div class="stat-box">
        <h2><?php echo $totalBookings; ?></h2>
        <p>Your Bookings</p>
    </div>

    <div class="stat-box">
        <h2>Active</h2>
        <p>Status</p>
    </div>

</div>

<h2 style="margin-top:40px;">Available Cars</h2>

<div class="car-grid">

<?php
$result = mysqli_query($conn, "SELECT * FROM cars");

while($row = mysqli_fetch_assoc($result)){
    echo "
    <div class='car'>
        <img src='images/{$row['image']}'>
        <h3>{$row['name']}</h3>
        <p class='price'>৳ {$row['price']} / day</p>
        <a class='btn' href='book.php?car_id={$row['id']}'>Book Now</a>
    </div>";
}
?>

</div>

</div>

<?php include 'footer.php'; ?>

</body>
</html>