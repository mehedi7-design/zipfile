<div class="footer">
    <p>© 2026 CarRental Pro | All Rights Reserved</p>
</div>