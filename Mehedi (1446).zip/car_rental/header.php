<div class="navbar">
    <div><b>🚗 LuxuryDrive</b></div>

    <div>
        <a href="index.php">Home</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
        <a href="dashboard.php">Dashboard</a>
    </div>
</div>