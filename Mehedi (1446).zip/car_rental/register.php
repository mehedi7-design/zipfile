<?php
include 'config.php';

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    mysqli_query($conn, "INSERT INTO users(name,email,password) VALUES('$name','$email','$password')");

    echo "<script>alert('Registration Successful! Please login'); window.location='login.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<h1>🚗 Car Rental Register</h1>

<form method="POST">
    <input type="text" name="name" placeholder="Enter Name" required><br>
    <input type="email" name="email" placeholder="Enter Email" required><br>
    <input type="password" name="password" placeholder="Enter Password" required><br>
    <button type="submit" name="register">Register</button>
</form>

<p style="text-align:center;">
    Already have an account? <a href="login.php">Login</a>
</p>

</body>
</html>