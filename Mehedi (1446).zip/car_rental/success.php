<?php include 'header.php'; ?>

<link rel="stylesheet" href="style.css">

<div class="hero">
    <h1>Booking Confirmed 🎉</h1>
    <p>Your car has been successfully booked</p>
</div>

<div class="container">
    <a class="btn" href="dashboard.php">Go to Dashboard</a>
</div>

<?php include 'footer.php'; ?>